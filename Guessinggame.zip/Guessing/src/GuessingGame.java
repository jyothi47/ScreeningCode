import java.util.Random;
import java.util.Scanner;

/**
 * 
 */

/**2
 * @author jm478_000
 *
 */
public class GuessingGame {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		   int a = 1 + (int) (Math.random() * 99); // initializing random number 
		   int min=1;
		   int max=100;
		   range rg= new range();// Creating a new object for the random number generation
		   input ip=new input(); // Creating a new object for the function input
		   System.out.println("WELCOME TO GUESSING GAME");
		   System.out.println("Think of a number from 1 to 100 ...I will guess what it is ?");
		   ip.ready();
		   System.out.println("Is the number "+a);
		   String c = ip.input();
		   while(c!=null)   //  Start of Loop for guessing number
		   {
		  	   if(c.equalsIgnoreCase("yes"))
		  	   {
		   	   System.out.println("Hurray");
		   	   System.out.println("The number is "+a);
			   System.exit(a);
			   }
		   else if(c.equalsIgnoreCase("lower"))
		   	   {
			   max =a-1;
			   a = rg.rangeNumbers(min, (a-1));
			   if(min==max)
			   	{  System.out.println("Hurray");
				   System.out.println("The number is "+a);
				   System.exit(a);
			   	}
			   else
				{  
				   System.out.println("Is the number "+a);
			       c=ip.input();
		        }
			   }
		   else if(c.equalsIgnoreCase("higher"))
		      {
			   min=a+1;
			   a = rg.rangeNumbers((a+1),max);
			   if(min==max)
			   {   System.out.println("Hurray");
				   System.out.println("The number is "+a);
				   System.exit(a);
			   }
			   else
			   {    
				   System.out.println("Is the number "+a);
			       c=ip.input();
			   }
		     }
		   else { System.out.println("you must type lower,higher or yes");c=ip.input();}
		   }
		}
}	