import java.util.Random;

public class range 
{
	Random rand = new Random();
	public int rangeNumbers(int min,int max)
	{
	int randomNum = rand.nextInt((max-min)+1)+min;// Rendom number generation
	return randomNum;
	}
}
