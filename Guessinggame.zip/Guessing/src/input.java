import java.util.Scanner;

public class input 
{   // Function for getting the input from the user
	public String input()
	{
	System.out.println("can you tell me the number of your choice is lower or higher or yes");
	Scanner sc1 = new Scanner(System.in);
	String c1=sc1.next();
    return c1;  
	}
	public void ready()
	{
		  System.out.println("Type 'ready' when you like to start or 'end' to exit");
		  Scanner sc = new Scanner(System.in);
		  String c=sc.next();
		  if(c.equalsIgnoreCase("ready"))
	  	  	   System.out.println("lets start the game");
		  else if(c.equalsIgnoreCase("end"))
		  {  System.out.println("Game has been stopped on user request");System.exit(0);}
		  else { 
			    System.out.println("Please type 'ready' or 'end' ");
			    System.out.println("You still want to continue the game \nPress 'yes' to continue or 'end' to end the game");
			    Scanner sc2 = new Scanner(System.in);
				String c2=sc.next();
				choice(c2);
			    }
		}
	public void choice(String c2)
	{
		if(c2.equalsIgnoreCase("yes"))
	  	  	ready();
		else if (c2.equalsIgnoreCase("end"))
			{System.out.println("Game has been stopped on user request");System.exit(0);}
		else 
		{System.out.println("you had given the wrong input\ncome again to play the game");System.exit(0);}
	}
}
